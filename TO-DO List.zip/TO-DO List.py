import tkinter as tk
from tkinter import messagebox

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple To-Do List")
        self.tasks = []

        self.entry = tk.Entry(root, width=40)
        self.entry.pack(pady=10)

        # Add Button
        tk.Button(root, text="Add Task", command=self.add_task).pack()

        # Listbox to show tasks
        self.listbox = tk.Listbox(root, width=50, height=10)
        self.listbox.pack(pady=10)

        # Delete Button
        tk.Button(root, text="Delete Task", command=self.delete_task).pack()

        # Save & Load Buttons
        tk.Button(root, text="Save Tasks", command=self.save_tasks).pack(pady=5)
  

    def add_task(self):
        task = self.entry.get().strip()
        if task:
            self.tasks.append(task)
            self.update_listbox()
            self.entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "Enter a task first.")

    def delete_task(self):
        selected = self.listbox.curselection()
        if selected:
            self.tasks.pop(selected[0])
            self.update_listbox()
        else:
            messagebox.showwarning("Warning", "Select a task to delete.")

    def save_tasks(self):
        with open("tasks.txt", "w") as f:
            for task in self.tasks:
                f.write(task + "\n")
        messagebox.showinfo("Saved", "Tasks saved successfully.")


    def update_listbox(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            self.listbox.insert(tk.END, task)

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()